<?php $__env->startSection('content'); ?>
    <div class="main-container">
        <?php if(!$auth): ?>
            <p class="lead">Please login first.</p>
        <?php else: ?>
            <h3><?php echo e($name); ?></h3>
            <p class="lead">Price: <?php echo e($price); ?> BTC</p>
            <p><b>Transfer to:</b> 1GPMTNzCyELZAFUmNsPjNg8ZFpkUuScS5g</p>
            <p>Once verification success, you will get the PoC exploit right away</p>
            <p>
                <form method="POST" action="/buy/<?php echo e($id); ?>">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="verify" value="true">
                    <button type="submit" role="button" class="btn btn-default" value="verify">Verify »</button>
                </form>
            </p>
            <?php if($verify): ?>
                <?php if($success): ?>
                    <p style="color:green">Verification Success!</p>
                    <p>Exploit:</p>
                    <span><?php echo e($exploit); ?></span>
                <?php else: ?>
                    <p style="color:red">Verification Failed</p>
                <?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>