<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width">
    <title>Zero Days Store</title>
    <meta name="description" content="The Number #1 Marketplace for Zero Days">
    <link rel="stylesheet" href="<?php echo e(load_asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(load_asset('css/bootstrap-social.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(load_asset('css/font-awesome.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.css">
    <link rel="stylesheet" href="<?php echo e(load_asset('css/main.css')); ?>">
</head>
<body>
    <?php echo $__env->make('layouts.partials.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <footer class="footer">
        <div class="container text-center">
        <p class="pull-left">© 2016 Zero Days Store.</p>
        </div>
    </footer>

    <script src="<?php echo e(load_asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(load_asset('js/bootstrap.min.js')); ?>"></script>
</body>
</html>
