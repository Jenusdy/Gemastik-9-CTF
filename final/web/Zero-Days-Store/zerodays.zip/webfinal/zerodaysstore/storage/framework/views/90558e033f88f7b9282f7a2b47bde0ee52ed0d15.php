<?php $__env->startSection('content'); ?>
    <div class="main-container">
         <h1>Welcome!</h1>
         <p class="lead">Number #1 Marketplace for High-Profile Zero Days in DarkNet.</p>

         <hr>

         <div class="row">
            <div class="col-sm-6">
                <h3>Linux Kernel 4.7.6 Local Root Exploit</h3>
                <p>Price: 150 BTC</p>
                <p><a href="buy/1" role="button" class="btn btn-default">Buy »</a></p>
            </div>
            <div class="col-sm-6">
                <h3>Google Chrome 55 RCE - Heap Exploit</h3>
                <p>Price: 500 BTC</p>
                <p><a href="buy/2" role="button" class="btn btn-default">Buy »</a></p>
            </div>
            <div class="col-sm-6">
                <h3>nginx-1.11.5 Denial of Service</h3>
                <p>Price: 50 BTC</p>
                <p><a href="buy/3" role="button" class="btn btn-default">Buy »</a></p>
            </div>
            <div class="col-sm-6">
                <h3>Docker 1.12 Breakout Exploit</h3>
                <p>Price: 350 BTC</p>
                <p><a href="buy/4" role="button" class="btn btn-default">Buy »</a></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>