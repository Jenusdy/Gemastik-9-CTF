    <div class="page-header">
        <h3>Profile Information</h3>
    </div>

    <form role="form" method="POST" action="<?php echo e(route('account.profile')); ?>" class="form-horizontal">
        <?php echo csrf_field(); ?>

        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
            <label for="name" class="col-sm-2 control-label">Email</label>
            <div class="col-sm-4">
                <input type="text" name="email" id="email" value="<?php echo e($account->email ?: old('email')); ?>" autofocus="" class="form-control">
                <?php if($errors->has('email')): ?>
                    <span class="help-block"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
            <label for="fullname" class="col-sm-2 control-label">Name</label>
            <div class="col-sm-4">
                <input type="text" name="fullname" id="name" value="<?php echo e($account->fullname ?: old('fullname')); ?>" class="form-control">
                <?php if($errors->has('fullname')): ?>
                    <span class="help-block"><?php echo e($errors->first('fullname')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-8">
                <button type="submit" class="btn btn-primary"><i class="fa fa-pencil"></i> Update Profile</button>
            </div>
        </div>
    </form>



