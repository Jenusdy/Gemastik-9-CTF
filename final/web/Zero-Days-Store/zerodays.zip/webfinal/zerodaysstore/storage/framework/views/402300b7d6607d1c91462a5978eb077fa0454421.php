<?php $__env->startSection('content'); ?>
    <div class="main-container">

        <?php echo $__env->make('layouts.partials.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="page-header">
            <h3>Account Deletion Confirmation</h3>
        </div>

        <p> Are you sure you want to delete your account </p>


        <form  method="POST" action="<?php echo e(route('account.delete.now')); ?>">
            <?php echo csrf_field(); ?>

            <button type="submit" class="btn btn-danger"><i class="fa fa-check"></i> Yes</button>

            <a href="<?php echo e(route('account.dont.delete')); ?>" class="btn btn-primary">
                <i class="fa fa-close"></i> No
            </a>
        </form>





    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>