<?php

namespace App\Http\Controllers;

use Auth;

class PageController extends Controller
{
    
    /**
     * Return the homepage view
     * @return mixed
     */   
    public function home()
    {
        return view('welcome');

    } 

    /**
     * Return the buy page view
     * @return mixed
     */ 
    public function buy($id)
    {
        switch ($id) {
            case 1:
                $name = "Linux Kernel 4.7.6 Local Root Exploit";
                $price = 150;
                break;
            case 2:
                $name = "Google Chrome 55 RCE - Heap Exploit";
                $price = 500;
                break;
            case 3:
                $name = "nginx-1.11.5 Denial of Service";
                $price = 50;
                break;
            case 4:
                $name = "Docker 1.12 Breakout Exploit";
                $price = 350;
                break;
            default:
                return redirect('/');
                break;
        }
        if (isset($_POST['verify'])) {
            $verify = true;
        } else {
            $verify = false;
        }

        // Success always false, exploit always empty ( ͡° ͜ʖ ͡°)

        return view('buy', ['id' => $id, 'auth' => Auth::check(),
                            'name' => $name, 'price' => $price,
                            'success' => false, 'exploit' => "",
                            'verify' => $verify]);
    }    

    /**
     * Return the contact page view
     * @return mixed
     */ 
    public function contact()
    {
        return view('contact');

    }
}
