<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Mail;
use App\Http\Requests;

class ContactController extends Controller
{
    /**
     * Send a mail with the message to the email specified in the contact form
     *
     * @param  Request  $request
     * @return Response
     */
    public function sendMessage(Request $request)
    {
        $this->validate($request, [
            'name'     => 'required|min:3',
            'email' => 'required|email|max:255',
            'message'    => 'required'
        ]);

        $name = lrtrim($request->input('name'));
        $emailToSendTo = $request->input('email');
        $body = lrtrim($request->input('message'));

        return redirect()->route('contact')->with('info', trans('texts.contact.sent_success'));
    }

}
