@extends('layouts.master')

@section('content')
    <div class="main-container">
        @if (!$auth)
            <p class="lead">Please login first.</p>
        @else
            <h3>{{ $name }}</h3>
            <p class="lead">Price: {{ $price }} BTC</p>
            <p><b>Transfer to:</b> 1GPMTNzCyELZAFUmNsPjNg8ZFpkUuScS5g</p>
            <p>Once verification success, you will get the PoC exploit right away</p>
            <p>
                <form method="POST" action="/buy/{{ $id }}">
                    {{ csrf_field() }}
                    <input type="hidden" name="verify" value="true">
                    <button type="submit" role="button" class="btn btn-default" value="verify">Verify »</button>
                </form>
            </p>
            @if ($verify)
                @if ($success)
                    <p style="color:green">Verification Success!</p>
                    <p>Exploit:</p>
                    <span>{{ $exploit }}</span>
                @else
                    <p style="color:red">Verification Failed</p>
                @endif
            @endif
        @endif
    </div>
@stop