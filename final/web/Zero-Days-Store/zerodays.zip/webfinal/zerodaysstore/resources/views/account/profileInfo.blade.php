    <div class="page-header">
        <h3>Profile Information</h3>
    </div>

    <form role="form" method="POST" action="{{ route('account.profile') }}" class="form-horizontal">
        {!! csrf_field() !!}
        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
            <label for="name" class="col-sm-2 control-label">Email</label>
            <div class="col-sm-4">
                <input type="text" name="email" id="email" value="{{ $account->email ?: old('email') }}" autofocus="" class="form-control">
                @if ($errors->has('email'))
                    <span class="help-block">{{ $errors->first('email') }}</span>
                @endif
            </div>
        </div>
        <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
            <label for="fullname" class="col-sm-2 control-label">Name</label>
            <div class="col-sm-4">
                <input type="text" name="fullname" id="name" value="{{ $account->fullname ?: old('fullname') }}" class="form-control">
                @if ($errors->has('fullname'))
                    <span class="help-block">{{ $errors->first('fullname') }}</span>
                @endif
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-8">
                <button type="submit" class="btn btn-primary"><i class="fa fa-pencil"></i> Update Profile</button>
            </div>
        </div>
    </form>



