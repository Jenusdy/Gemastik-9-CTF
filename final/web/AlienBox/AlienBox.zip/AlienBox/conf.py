config = dict()

config["HOST"] = "127.0.0.1"
config["PORT"] = 5000
config["DEBUG"] = False
config['UPLOAD_FOLDER'] = 'f/'
config['MAX_CONTENT_LENGTH'] = 40 * 1024 * 1024
config['ALLOWED_EXTENSIONS'] = set(['ass', 'odt', 'docx', 'doc', 'css', 'zip', 'ogg', 'mp3', 'wmv', 'mp4', 'txt', 'webm', 'gif', 'jpeg', 'jpg', 'png','mkv','psd','flac'])
config["THREADED"] = True
config["SITE_DATA"] = {
  "title": "AlienBox"
}
